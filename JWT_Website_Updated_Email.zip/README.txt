JALOOTH WELFARE TRUST — WEBSITE STARTER

Files:
- index.html: the homepage
- style.css: colors, layout, responsive design
- script.js: mobile menu and copy buttons
- assets/jwt-logo.png: supplied JWT logo
- assets/bank-banner.jpg: JWT bank banner reference

LOCAL PREVIEW
Open index.html in a browser. For full functionality (including clipboard), preview through a local web server or published HTTPS site.

FREE GITHUB PAGES HOSTING
1. Create a free account at https://github.com
2. Click + > New repository. Name it jwt-website (or another name), select Public, then Create repository.
3. Upload index.html, style.css, script.js, and the assets folder contents, preserving the folder structure. The easiest way is to unzip first and upload the files using Add file > Upload files.
4. Open repository Settings > Pages.
5. Under Build and deployment choose Deploy from a branch, branch main, folder /(root), then Save.
6. After deployment, open https://YOUR-USERNAME.github.io/jwt-website/

IMPORTANT BEFORE PUBLIC LAUNCH
- Confirm JWT's official description, legal status and charitable activities.
- Add approved photographs and real captions in the Gallery section.
- WhatsApp and Facebook are configured. Add a verified email address when available.
- Verify bank beneficiary name and IBAN with JWT before collecting donations.
- Do not imply online payments are processed: the current site only displays bank transfer instructions.
- A custom domain is optional and typically costs extra. GitHub Pages provides a free github.io address.
